
public class Kendaraan {
    private String jenis;
    private int kapasitas;

    public Kendaraan(String jenis, int kapasitas) {
        this.jenis = jenis;
        this.kapasitas = kapasitas;
    }

    public String getJenis() {
        return jenis;
    }

    public int getKapasitas() {
        return kapasitas;
    }
}

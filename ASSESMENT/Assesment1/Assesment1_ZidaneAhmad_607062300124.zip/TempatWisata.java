
public class TempatWisata {
    private String nama;
    private int biaya;

    public TempatWisata(String nama, int biaya) {
        this.nama = nama;
        this.biaya = biaya;
    }

    public String getNama() {
        return nama;
    }

    public int getBiaya() {
        return biaya;
    }
}


public class Traveller {
    private String nama;
    private String asal;

    public Traveller(String nama, String asal) {
        this.nama = nama;
        this.asal = asal;
    }

    public String getNama() {
        return nama;
    }

    public String getAsal() {
        return asal;
    }
}
